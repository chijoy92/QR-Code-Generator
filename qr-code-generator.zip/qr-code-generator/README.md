# QR Studio | QR Code Generator

A free, responsive QR code generator built with **HTML, CSS, and vanilla JavaScript**. Create QR codes for websites, text, Wi-Fi, email, and phone numbers. Choose colors and image size, then export your QR code as PNG or SVG.

Everything runs **locally in your browser**, including QR generation. There are no uploads, accounts, APIs, or runtime dependencies.

## Features

- Generate QR codes for websites, plain text, Wi-Fi networks, email messages, and phone numbers
- Customize foreground and background colors
- Choose PNG export sizes (256, 512, or 1024 pixels)
- Download crisp SVG vector files
- Select error correction levels (L, M, Q, H)
- Mobile-friendly layout
- Offline support after downloading the repository
- No API keys, database, or server needed

## Tech stack

HTML5, CSS3, JavaScript, Canvas API, and an MIT-licensed JavaScript QR encoder.

## Run in VS Code (Windows, macOS, Linux)

1. On GitHub, click **Code > Download ZIP**, then extract the ZIP. Alternatively, clone the repository by copying its HTTPS URL from the **Code** menu and running `git clone <copied-url>` in your terminal.
2. Open **Visual Studio Code**.
3. Choose **File > Open Folder** and select the `qr-code-generator` folder.
4. Open `index.html` in a browser. That is all you need.

**Optional: use Live Server in VS Code**

1. Install the **Live Server** extension (by Ritwick Dey).
2. Right-click `index.html` and choose **Open with Live Server**.
3. The app opens in your browser, typically at `http://127.0.0.1:5500`.

No `npm install`, Python setup, or backend is required.

## How to use

1. Choose **Website**, **Text**, **Wi-Fi**, **Email**, or **Phone**.
2. Enter your information.
3. Optionally customize the colors, image size, and correction level.
4. Click **Generate QR Code**.
5. Click **PNG** or **SVG** to download your code.

For reliable scanning, use contrasting dark and light colors and avoid making the QR code too dense.

## Run automated tests

If Node.js 18 or later is installed, run this in the VS Code terminal:

```bash
node --test tests/qr.test.cjs
```

The app itself does not need Node.js. Tests cover QR matrix generation and payload creation and validation.

## Project structure

```text
qr-code-generator/
├── index.html
├── assets/
│   ├── app.js
│   └── styles.css
├── vendor/
│   ├── qr-engine.js
│   └── LICENSE.txt
├── tests/
│   └── qr.test.cjs
├── .gitignore
├── LICENSE
└── README.md
```

## Publish with GitHub Pages

1. Create a **public repository** named `qr-code-generator` on GitHub.
2. Upload the project files (keep `index.html` at the repository root), or push them using Git.
3. Go to the repository's **Settings > Pages**.
4. Under **Build and deployment**, select **Deploy from a branch**.
5. Select branch **main**, folder **/(root)**, then click **Save**.
6. Once GitHub completes deployment, open the published URL shown in the Pages settings.

GitHub Pages is suitable because this app is fully static.

## Notes

- Generated codes are static: changing the destination later requires generating a new QR code.
- The app supports Unicode text via UTF-8 encoding.
- Avoid publishing sensitive Wi-Fi credentials in QR codes you share publicly.
- QR content has a practical limit, and especially long inputs may not fit at high correction settings.

## Third-party attribution

The bundled QR encoding implementation is based on **QRCode for JavaScript**, copyright (c) 2009 Kazuhiko Arase, MIT License. See [`vendor/LICENSE.txt`](vendor/LICENSE.txt). It is included locally so the site works without a CDN.

## License

This project is available under the MIT License. See [LICENSE](LICENSE).
